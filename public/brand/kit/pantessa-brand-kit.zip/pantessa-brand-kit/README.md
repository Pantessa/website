# Pantessa brand kit

Logos, colours, tiles and backgrounds for writing about Pantessa or linking
to it. Version 2026-11-24. https://www.pantessa.com

Start with `pantessa-brand-guidelines.pdf`.

| Folder | What |
|---|---|
| `logo/` | The Cut P: mark, lockup, stacked, wordmark, avatar, app icon. SVG, with PNG in `logo/png/` |
| `colour/` | The palette as CSS and JSON, and two palette sheets |
| `tiles/` | The brand tile in seven colours, and four-tile pieces |
| `backgrounds/` | Backgrounds with no text, in link-card, square, story and slide sizes |

Fonts are Fraunces, Geist and Geist Mono, free from Google Fonts.

## Using it

- Use these files to refer to Pantessa: press, listings, integrations.
- Do not change the logo: no new colours, no rotation, no effects.
- Do not suggest that Pantessa sponsors or endorses you unless we have agreed.
- Pantessa was formerly Yeetful. Please use the current name and mark.

Questions: hello@pantessa.com
